from utils import format_currency, validate_email

print(format_currency(250000))
print(validate_email("test@yahoo.com"))