from helpers import capitalize_words, is_prime

print(capitalize_words("xin chao cac ban"))
print(is_prime(29))