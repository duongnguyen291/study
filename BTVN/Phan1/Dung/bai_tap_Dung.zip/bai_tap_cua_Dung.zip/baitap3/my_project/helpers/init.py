# Export các hàm quan trọng
from .string_utils import capitalize_words
from .number_utils import is_prime, factorial