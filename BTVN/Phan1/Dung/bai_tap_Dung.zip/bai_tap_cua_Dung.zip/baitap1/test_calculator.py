import calculator
from calculator import add, sub

print(calculator.mul(3, 5))
print(calculator.div(10, 2))

print(add(2, 7))
print(sub(9, 4))